#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * ${DATE}
 *
 * @author XL
 * @version 1.0
 */
public class ${NAME} {
}
